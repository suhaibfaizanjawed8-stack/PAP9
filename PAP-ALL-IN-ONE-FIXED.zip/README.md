# Prince Art Packages — Vercel / GitHub Ready Static Website

This is a complete, self-contained static website for **Prince Art Packages (Private) Limited**.

It is prepared specifically to avoid common deployment errors on Vercel and GitHub Pages (such as `404 NOT_FOUND` caused by incorrect Output Directory settings).

## Important: How to Upload Correctly

1. **Extract this ZIP completely** on your computer.
2. Create a new empty GitHub repository (or empty existing one).
3. Upload **ALL** the extracted files and folders into the **root** of the repository.
   - You must see `index.html`, `package.json`, `vercel.json`, `scripts/`, `assets/`, `products/`, etc. directly at the repository root.
   - Do **NOT** upload the ZIP file itself.
   - Do **NOT** put everything inside an extra folder.

## Deploy to Vercel (Recommended)

1. Import the GitHub repository into Vercel.
2. Use these exact settings (or leave defaults if they match):
   - **Framework Preset**: Other
   - **Root Directory**: `./` (leave blank / root)
   - **Build Command**: `npm run build`
   - **Output Directory**: `dist`
   - **Install Command**: leave empty (or `npm install` — there are zero dependencies)

3. Deploy.

The build step simply copies the complete site into `dist/` (and also creates a `public/` fallback copy). This guarantees Vercel always finds the files no matter what Output Directory override may exist in the project dashboard.

## Deploy to GitHub Pages

- The included `.nojekyll` file disables Jekyll processing.
- Set GitHub Pages source to the root (or `/docs` if you prefer to move files).
- Absolute paths (`/assets/...`) work when the site is served from the domain root.

## Local Preview

```bash
# Optional: run the verification (checks all local links)
npm run check

# Optional: run the build (creates dist/ and public/)
npm run build

# Then open index.html in a browser, or use any static server:
npx serve .
```

## Project Structure

- `index.html` + all page folders (`about/`, `products/`, `blog/`, …)
- `assets/` — images, fonts, icons
- `design.css`, `brand-colors.css`, `interactions.js`
- `scripts/build.mjs` — copies site → `dist/` + `public/`
- `scripts/verify-site.mjs` — validates local href/src references
- `vercel.json` — correct Vercel configuration
- `.nojekyll` — GitHub Pages compatibility

## Version

1.0.4 — Clean, fully verified, error-free package.
