import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const errors = [];
const htmlFiles = [];
const cssFiles = [];

function walk(dir) {
  for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
    if (['node_modules', '.git', '.vercel', 'dist'].includes(ent.name)) continue;
    const p = path.join(dir, ent.name);
    if (ent.isDirectory()) walk(p);
    else if (ent.isFile()) {
      if (p.endsWith('.html')) htmlFiles.push(p);
      if (p.endsWith('.css')) cssFiles.push(p);
    }
  }
}

function localTarget(url, fromFile, isHref = false) {
  if (!url) return null;
  url = url.trim();
  if (/^(https?:|mailto:|tel:|data:|javascript:)/i.test(url) || url.startsWith('#')) return null;
  const clean = url.split('#')[0].split('?')[0];
  if (!clean) return null;
  let target;
  if (clean.startsWith('/')) target = path.join(root, clean.replace(/^\/+/, ''));
  else target = path.resolve(path.dirname(fromFile), clean);

  if (isHref) {
    if (clean.endsWith('/')) target = path.join(target, 'index.html');
    else if (!path.extname(target)) {
      if (fs.existsSync(path.join(target, 'index.html'))) target = path.join(target, 'index.html');
      else if (fs.existsSync(`${target}.html`)) target = `${target}.html`;
    }
  }
  return target;
}

function checkRef(url, fromFile, isHref = false) {
  const target = localTarget(url, fromFile, isHref);
  if (!target) return;
  if (!fs.existsSync(target)) errors.push(`${path.relative(root, fromFile)} -> ${url}`);
}

if (!fs.existsSync(path.join(root, 'index.html'))) errors.push('Missing root index.html');
if (!fs.existsSync(path.join(root, 'assets/images/logo.png'))) errors.push('Missing official logo assets/images/logo.png');
walk(root);

const attrRe = /\b(href|src)=["']([^"']+)["']/gi;
for (const file of htmlFiles) {
  const text = fs.readFileSync(file, 'utf8');
  for (const m of text.matchAll(attrRe)) checkRef(m[2], file, m[1].toLowerCase() === 'href');
}

const urlRe = /url\((['"]?)([^)'"\s]+)\1\)/gi;
for (const file of cssFiles) {
  const text = fs.readFileSync(file, 'utf8');
  for (const m of text.matchAll(urlRe)) checkRef(m[2], file, false);
}

if (errors.length) {
  console.error('\nSite verification failed:');
  for (const e of errors) console.error(` - ${e}`);
  process.exit(1);
}

console.log(`Site verification passed: ${htmlFiles.length} HTML pages, ${cssFiles.length} CSS files.`);
console.log('Official logo found. All checked local href/src/url() references resolve.');
