import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const targets = [path.join(root, 'dist'), path.join(root, 'public')];
const excludedTopLevel = new Set([
  '.git', '.github', '.vercel', 'dist', 'public', 'node_modules', 'scripts',
  'package.json', 'package-lock.json', 'vercel.json', 'README.md', '.gitignore'
]);

function copyEntry(src, dest) {
  const stat = fs.statSync(src);
  if (stat.isDirectory()) {
    fs.mkdirSync(dest, { recursive: true });
    for (const name of fs.readdirSync(src)) copyEntry(path.join(src, name), path.join(dest, name));
  } else if (stat.isFile()) {
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.copyFileSync(src, dest);
  }
}

const rootIndex = path.join(root, 'index.html');
if (!fs.existsSync(rootIndex)) {
  console.error('Build failed: root index.html is missing.');
  process.exit(1);
}

for (const target of targets) {
  fs.rmSync(target, { recursive: true, force: true });
  fs.mkdirSync(target, { recursive: true });

  for (const name of fs.readdirSync(root)) {
    if (excludedTopLevel.has(name)) continue;
    copyEntry(path.join(root, name), path.join(target, name));
  }

  if (!fs.existsSync(path.join(target, 'index.html'))) {
    console.error(`Build failed: ${path.basename(target)}/index.html was not created.`);
    process.exit(1);
  }
  if (!fs.existsSync(path.join(target, 'assets', 'images', 'logo.png'))) {
    console.error(`Build failed: logo missing from ${path.basename(target)}/assets/images/logo.png.`);
    process.exit(1);
  }
}

console.log('Build complete. Static site is available at:');
console.log(' - project root/index.html');
console.log(' - dist/index.html (Vercel configured output)');
console.log(' - public/index.html (fallback for dashboard output override)');
