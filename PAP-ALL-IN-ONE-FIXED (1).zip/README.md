# Prince Art Packages — Vercel / GitHub Ready

This package is intentionally prepared to avoid Vercel `404 NOT_FOUND` caused by an incorrect Output Directory.

The complete site exists at the project root, and the build also creates identical copies in `dist/` and `public/`.

## GitHub
Extract the ZIP, then upload ALL extracted files/folders to the repository root. Do not upload only the ZIP.

The repository root must visibly contain `index.html`, `package.json`, `vercel.json`, `scripts/`, `assets/`, and the page folders.

## Vercel
Recommended settings:
- Framework Preset: Other
- Root Directory: `./`
- Build Command: `npm run build`
- Output Directory: `dist`

If Vercel has an old Output Directory override such as `public`, this project also builds a complete `public/` copy.
